"""Saved independent arithmetic check for this synthetic research, not agent code."""
import csv
import hashlib
import json
from collections import defaultdict
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PARAMETERS = {
    "source_id": "src-c416139ba6336a46c45db25c",
    "input": "inputs/metrics.csv",
    "periods": ["2026-09", "2026-10"],
    "eligibility_column": "complete_window",
    "missing_policy": "error",
    "units": "proportion",
    "definition": "Activated owners / eligible owners, full 7x24h UTC window, synthetic disjoint aggregates.",
    "decomposition": "mix=sum((w_new-w_old)*r_old); within=sum(w_new*(r_new-r_old)); descriptive only",
}


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def run():
    source = next(json.loads(line) for line in (ROOT / "sources.jsonl").read_text(encoding="utf-8").splitlines()
                  if json.loads(line)["id"] == PARAMETERS["source_id"])
    payload = (ROOT / PARAMETERS["input"]).read_bytes()
    assert source["synthetic"] is True
    assert sha(payload) == source["sha256"] == sha((ROOT / source["snapshot_path"]).read_bytes())
    with (ROOT / PARAMETERS["input"]).open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    grouped = defaultdict(lambda: [0, 0])
    overall = defaultdict(lambda: [0, 0])
    keys = set()
    used = excluded = 0
    for row in rows:
        assert all(value not in (None, "") for value in row.values())
        key = row["period"], row["channel"]
        assert key not in keys, "Duplicate period/channel aggregate"
        keys.add(key)
        assert row["complete_window"] in ("true", "false", "1", "0")
        if row["period"] not in PARAMETERS["periods"] or row["complete_window"] not in ("true", "1"):
            excluded += 1
            continue
        numerator, denominator = int(row["activated_7d"]), int(row["eligible_users"])
        assert 0 <= numerator <= denominator and denominator > 0
        for bucket in (grouped[key], overall[row["period"]]):
            bucket[0] += numerator
            bucket[1] += denominator
        used += 1
    assert used > 0
    rates = {key: Fraction(*value) for key, value in grouped.items()}
    totals = {period: Fraction(*value) for period, value in overall.items()}
    checked_cli = []
    for result_path in sorted((ROOT / "calculations").glob("*/result.json")):
        result = json.loads(result_path.read_text(encoding="utf-8"))
        spec = json.loads((ROOT / result["spec_path"]).read_text(encoding="utf-8"))
        assert result["source_id"] == PARAMETERS["source_id"]
        groups = spec["group_by"]
        assert groups in (["period"], ["period", "channel"])
        for entry in result["groups"]:
            group = entry["group"]
            expected = overall[group["period"]] if groups == ["period"] else grouped[(group["period"], group["channel"])]
            assert Fraction(entry["numerator"]) == expected[0]
            assert Fraction(entry["denominator"]) == expected[1]
            assert Fraction(entry["value"]) == Fraction(*expected)
        checked_cli.append(result["id"])
    assert len(checked_cli) == 2, "Both CLI calculations must exist"
    old, new = PARAMETERS["periods"]
    channels = sorted({channel for period, channel in grouped if period == old})
    assert set(channels) == {channel for period, channel in grouped if period == new}
    weights = {(period, channel): Fraction(grouped[(period, channel)][1], overall[period][1])
               for period in PARAMETERS["periods"] for channel in channels}
    mix = sum((weights[new, c] - weights[old, c]) * rates[old, c] for c in channels)
    within = sum(weights[new, c] * (rates[new, c] - rates[old, c]) for c in channels)
    change = totals[new] - totals[old]
    assert change == mix + within
    fixed_mix_new = sum(weights[old, c] * rates[new, c] for c in channels)
    result = {
        "synthetic": True, "parameters": PARAMETERS, "input_sha256": sha(payload),
        "script_sha256": sha(Path(__file__).read_bytes()), "checked_calculation_ids": checked_cli,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "checks": {"no_missing": True, "unique_aggregate_keys": True, "bounded_counts": True,
                   "matches_saved_snapshot": True, "cli_exact_match": True,
                   "window_dates_independently_verified": False},
        "records": {"used": used, "excluded": excluded},
        "overall": {p: {"activated": overall[p][0], "eligible": overall[p][1], "fraction": str(totals[p])}
                    for p in PARAMETERS["periods"]},
        "by_channel": [{"period": p, "channel": c, "fraction": str(rates[p,c]),
                        "weight_fraction": str(weights[p,c]), "activated": grouped[p,c][0],
                        "eligible": grouped[p,c][1]} for p,c in sorted(grouped)],
        "change_pp": str(change * 100), "relative_change": str(change / totals[old]),
        "mix_change_pp": str(mix * 100), "within_change_pp": str(within * 100),
        "new_period_at_old_weights": str(fixed_mix_new),
        "limitations": ["Synthetic aggregate arithmetic, not real demand or causal channel effects.",
                       "Window and distinct-user claims depend on synthetic product description; no raw dates.",
                       "Fixed weights are a standardisation, not a prediction of intervention outcomes."],
    }
    (ROOT / "drafts/independent-check.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True))


if __name__ == "__main__":
    run()
